let remote;

const footer = document.getElementsByTagName('footer')[0];

const codeEl = document.createElement('code');

const getUrl = fetch('/getcouchaddress').then(resp => resp.text());

const localDB = new PouchDB('doc-store');

const mainTextInput = document.getElementById('main-text-input');

const saveButton = document.getElementById('save-btn');

let pListDocument

var selected

getUrl.then(couchAddress => {
    remote = new PouchDB(couchAddress + 'portfolio-ui');
    console.log('remote: ', remote);
    setupListeners();
})

function log(what) {
    const toIns = codeEl.cloneNode().innerHTML = what;
    console.log('toIns: ', toIns);
    footer.innerHTML += toIns + '<br><br>';
}


function syncDb(){
    localDB.sync(remote)
}

function setupListeners() {

    localDB.changes({
        since: 'now',
        live: true,
        include_docs: true
    }).on('change', function (change) {
        log('LOCAL change: '+ JSON.stringify(change))
    }).on('complete', function (info) {
        log('LOCAL info: ', info)
    }).on('error', function (err) {
        log('LOCAL err: ', err)
    });

    syncDb();

    var listEl = document.getElementById('entry-list');
    
    localDB.get('6cf35dfe4649bc106f6be414da009680').then(doc=>{
        
        pListDocument = doc;
        doc.docs.forEach(e=> {
            const li = document.createElement('li');
            const a = document.createElement('a');
            a.onclick = anchorClick;
            a.href='#';
            a.innerHTML = e.title;
            li.appendChild(a);
            a.id = e.id;
            listEl.appendChild(li);
        })
    })
}