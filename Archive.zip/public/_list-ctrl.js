/**
 * List controls
 */

var elementID;

function anchorClick(ev) {
    textContainer.value = pListDocument.docs[ev.target.id].content;
    elementID = ev.target.id;
    updateMarkdownContainer()
    toggleBtn('save-btn');
}

function saveText() {
    pListDocument.docs[elementID].content = textContainer.value;
    toggleBtn('save-btn', true);
}

function clear() {
    textContainer.innerHTML = '';
    mdContainer.innerHTML = '';
}


function toggleBtn(btnId, boolParam) {
    const btnOperation = document.getElementById(btnId);
    if(boolParam===undefined){
        btnOperation.disabled = !btnOperation.disabled
    } else if (boolParam){
        btnOperation.disabled = true;
    } else if (!boolParam){
        btnOperation.disabled = false;
    }
}


saveButton.addEventListener('click', saveText)

