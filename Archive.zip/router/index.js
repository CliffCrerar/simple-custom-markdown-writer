/**
 * Routing sub apps
 */
// @ts-nocheck
 module.exports = {
     falcorAppRouter:require('./falcor-data-routing'),
     getUrl: require('./get-couch-url')
}