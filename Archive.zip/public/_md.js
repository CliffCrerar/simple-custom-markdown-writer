var textContainer = document.getElementById('editor');
var mdContainer = document.getElementById('markdown');

const updateMarkdownContainer = () => mdContainer.innerHTML = marked(textContainer.value);

var ableToSave = false;

textContainer.onkeyup = function () {
    console.log('keyup');
    ableToSave = true;
    updateMarkdownContainer()
}

